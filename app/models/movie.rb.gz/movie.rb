class Movie < ActiveRecord::Base
  
  def self.get_ratings
  	# params ||= {}
  end

	def self.all_movies
		Movie.find(params[:id])
	end

  def self.all_ratings	# self allows you to use without instantiating a method
    %w[G PG PG-13 R NC-17]
  end

end